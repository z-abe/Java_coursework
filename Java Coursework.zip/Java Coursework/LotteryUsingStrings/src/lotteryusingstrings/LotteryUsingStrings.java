/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lotteryusingstrings;

/**
 *
 * @author zacha
 */
import java.util.Scanner;
public class LotteryUsingStrings {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String lottery = "" + (int)(Math.random() * 10) +
                (int)(Math.random() * 10);
        
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your lottery pick (Two Digits): ");
        String guess = input.nextLine();
        
        char lotteryDigit1 = lottery.charAt(0);
        char lotteryDigit2 = lottery.charAt(1);
        
        char guessDigit1 = guess.charAt(0);
        char guessDigit2 = guess.charAt(1);
        
        System.out.println("The lottery number is " + lottery);
        
        if (guess.equals(lottery))
            System.out.println("Exact match: you win $10,000");
        else if (guessDigit2 == lotteryDigit1
                && guessDigit1 == lotteryDigit2)
            System.out.println("Match all digits: you win $3,000");
        else if (guessDigit1 == lotteryDigit1
                || guessDigit1 == lotteryDigit2
                || guessDigit2 == lotteryDigit1
                || guessDigit2 == lotteryDigit2)
            System.out.println("Match one digit: you win $1,000");
        else
            System.out.println("Sorry, no match");
    }
    
}
