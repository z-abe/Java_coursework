/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package simplecircle;

/**
 *
 * @author zacha
 */
public class SimpleCircle {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         SimpleCircle circle1 = new SimpleCircle();
        System.out.println("The area of the circle of radius "
        + circle1.radius + " is " + circle1.getArea());
        
        SimpleCircle circle2 = new SimpleCircle(25);
        System.out.println("The area of the circle of radius "
        + circle2.radius + " is " + circle2.getArea());
        
        SimpleCircle circle3 = new SimpleCircle(125);
        System.out.println("The area of the circle of radius "
        + circle3.radius + " is " + circle3.getArea());
        
        circle2.radius = 100;
        System.out.println("The area of the circle of radius "
        + circle2.radius + " is " + circle2.getArea());
    }   
    double radius;
    
    SimpleCircle(){
        radius = 1;
    }
    SimpleCircle(double newRadius){
        radius = newRadius;
    }
    double getArea(){
        return radius * radius * Math.PI;
    }
    double getPerimeter(){
        return 2 * radius * Math.PI;
    }
    void setRadius(double newRadius){
        radius = newRadius;
    }
}
    

