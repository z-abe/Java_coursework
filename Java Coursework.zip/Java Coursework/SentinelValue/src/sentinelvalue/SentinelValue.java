/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sentinelvalue;

/**
 *
 * @author zacha
 */
import java.util.Scanner;
public class SentinelValue {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.print("Enter an ineger (the input ends if it is 0): ");
        int data = input.nextInt();
        
        int sum = 0;
        while (data != 0){
            sum += data;
            
            System.out.print("Enter an integer (the input ends if it is 0): ");
            data = input.nextInt();
        }
        
        System.out.println("The sum is " + sum);
    }
    
}
