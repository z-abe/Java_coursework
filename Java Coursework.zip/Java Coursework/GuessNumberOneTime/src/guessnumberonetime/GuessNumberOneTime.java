/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package guessnumberonetime;

/**
 *
 * @author zacha
 */
import java.util.Scanner;
public class GuessNumberOneTime {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       int number = (int)(Math.random() * 101);
  
    Scanner input = new Scanner(System.in);
    System.out.println("Guess a magic number between 0 and 100");
 
    System.out.print("\nEnter your guess: ");
    int guess = input.nextInt();

    if (guess == number)
    System.out.println("Yes, the number is " + number);


    else if (guess > number)
    System.out.println("Your guess is too high");
    else
    System.out.println("Your guess is too low"); 
        
    }
    
}
