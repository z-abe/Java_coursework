/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package linearsearch;

/**
 *
 * @author zacha
 */
public class LinearSearch {

    /**
     * @param args the command line arguments
     */
    public static int linearSearch(int[] list, int key) {
        // TODO code application logic here
        for (int i = 0; i < list.length; i++){
        if (key == list[i])
            return i;
    }
        return -1;
    }
    
}
