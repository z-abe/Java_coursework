/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package faculty;

/**
 *
 * @author zacha
 */
public class Faculty extends Employee {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new Faculty();
    }
    public Faculty(){
        System.out.println("(4) Performs Faculty's Tasks");
    }
}

class Employee extends Person {
    public Employee(){
        this("(2) Invoke Employee's overloaded constructor");
        System.out.println("(3) Performs Employee's Tasks ");
    }
    
    public Employee(String s){
        System.out.println(s);
    }
}
class Person {
    public Person(){
        System.out.println("(1) Performs Person's Tasks");
    }
}
