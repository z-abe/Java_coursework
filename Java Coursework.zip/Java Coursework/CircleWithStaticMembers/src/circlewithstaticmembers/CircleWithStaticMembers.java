/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package circlewithstaticmembers;

/**
 *
 * @author zacha
 */
public class CircleWithStaticMembers {

    /**
     * @param args the command line arguments
     */
    double radius;
    
    static int numberOfObjects = 0;
    
    CircleWithStaticMembers() {
        radius = 1;
        numberOfObjects++;
    }
    
    CircleWithStaticMembers(double newRadius){
        radius = newRadius;
        numberOfObjects++;
    }
    
    static int getNumberOfObjects(){
        return numberOfObjects;
    }
    
    double getArea(){
        return radius * radius * Math.PI;
    }
}
