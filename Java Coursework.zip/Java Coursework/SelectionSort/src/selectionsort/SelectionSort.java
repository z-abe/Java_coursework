/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package selectionsort;

/**
 *
 * @author zacha
 */
public class SelectionSort {

    /**
     * @param args the command line arguments
     */
    public static void selectionSort(double[] list) {
        // TODO code application logic here
        for (int i = 0; i < list.length - 1; i++){
            double currentMin = list[i];
            int currentMinIndex = i;
            
            for (int j = i + 1; j < list.length; j++){
                if (currentMin > list[j])
                    currentMin = list[j];
                    currentMinIndex = j;
            }
        }
        if (currentMinIndex != i){
            list[currentMinIndex] = list[i];
            list[i] = currentMin;
        }
    }
    
}
