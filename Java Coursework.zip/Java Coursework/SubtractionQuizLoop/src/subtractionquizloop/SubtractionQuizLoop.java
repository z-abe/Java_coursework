/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package subtractionquizloop;

/**
 *
 * @author zacha
 */
import java.util.Scanner;
public class SubtractionQuizLoop {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    final int NUMBER_OF_QUESTIONS = 5; 
        int correctCount = 0; 
        int count = 0; 
        long startTime = System.currentTimeMillis();
        String output = " "; 
        Scanner input = new Scanner(System.in);

        while (count < NUMBER_OF_QUESTIONS) {

        int number1 = (int)(Math.random() * 10);
        int number2 = (int)(Math.random() * 10);

        if (number1 < number2) {
        int temp = number1;
        number1 = number2;
        number2 = temp;
        }

        System.out.print("What is " + number1 + " - " + number2 + "? ");
        int answer = input.nextInt();


        if (number1 - number2 == answer) {
        System.out.println("You are correct!");
        correctCount++; 
        }
        else
        System.out.println("Your answer is wrong.\n" + number1 
        + " - " + number2 + " should be " + (number1 - number2));

      count++;

        output += "\n" + number1 + "-" + number2 + "=" + answer +
        ((number1 - number2 == answer) ? " correct" : " wrong");

        long endTime = System.currentTimeMillis();
        long testTime = endTime - startTime;

        System.out.println("Correct count is " + correctCount +
        "\nTest time is " + testTime / 1000 + " seconds\n" + output);
    
    }
   }
}