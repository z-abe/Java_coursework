/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package futuretuition;

/**
 *
 * @author zacha
 */
public class FutureTuition {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double tuition = 10000;
        int year = 0;
        while(tuition < 20000){
            tuition = tuition * 1.07;
            year++;
        }
        System.out.println("Tuition will be doubled in "
        + year + " years");
        System.out.printf("Tuition will be $%.2f in %1d years",
        tuition, year);
    }
    
}
